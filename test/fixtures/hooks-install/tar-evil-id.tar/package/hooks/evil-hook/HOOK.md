---
name: evil-hook
description: evil-hook
metadata: {"bot":{"events":["command:new"]}}
---

# evil-hook
