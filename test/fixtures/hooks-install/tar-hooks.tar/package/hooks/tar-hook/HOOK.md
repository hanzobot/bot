---
name: tar-hook
description: tar-hook
metadata: {"bot":{"events":["command:new"]}}
---

# tar-hook
