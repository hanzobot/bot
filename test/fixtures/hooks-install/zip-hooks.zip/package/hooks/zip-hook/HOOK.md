---
name: zip-hook
description: zip-hook
metadata: {"bot":{"events":["command:new"]}}
---

# zip-hook
