---
name: reserved-hook
description: reserved-hook
metadata: {"bot":{"events":["command:new"]}}
---

# reserved-hook
